<form action="post_event_process.php" method="POST" enctype="multipart/form-data">
    <input type="text" name="title" placeholder="Event Title" required>
    <textarea name="description" placeholder="Event Description" required></textarea>
    <input type="file" name="photo" accept=".jpg,.jpeg,.png" required>
    <input type="submit" value="Post Event">
</form>