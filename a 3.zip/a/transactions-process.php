<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'db_connection.php';

// Fetch existing transactions from the database
$query = "SELECT * FROM transactions";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$transactions = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
}

// Handle form submission for adding a new transaction
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $authorized_official = $_POST['authorized_official'];
    $item = $_POST['item'];
    $date = $_POST['date'];
    $budget = $_POST['budget'];
    $money = $_POST['money'];
    $recipient = $_POST['recipient'];
    
    // Initialize receipt variable
    $receipt = null;

    // Handle file upload
    if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
        $targetDir = 'uploads/';
        $fileName = basename($_FILES["receipt"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        // Move uploaded file to target directory
        if (move_uploaded_file($_FILES["receipt"]["tmp_name"], $targetFilePath)) {
            $receipt = $targetFilePath; // Store path for database insertion
        } else {
            echo "Error moving uploaded file.";
            exit();
        }
    } else {
        echo "No valid file uploaded.";
        exit();
    }

    // Prepare SQL statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO transactions (authorized_official, item, date, budget, money, recipient, receipt) VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    // Bind parameters and execute statement
    $stmt->bind_param("sssssss", $authorized_official, $item, $date, $budget, $money, $recipient, $receipt);

    if ($stmt->execute()) {
        header("Location: transactions.php"); // Redirect after successful insertion
        exit;
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    // Close statement
    $stmt->close();
}

// Close database connection
$conn->close();
?>