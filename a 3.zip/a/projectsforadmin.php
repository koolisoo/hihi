<?php
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}
require 'db_connection.php';

date_default_timezone_set('Asia/Manila');

$query = "
    SELECT p.*, a.info AS additional_info
    FROM projects p
    LEFT JOIN project_additional_info a ON p.id = a.project_id
    ORDER BY p.project_date ASC
";
$result = $conn->query($query);

$projects = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if (!isset($projects[$row['id']])) {
            $projects[$row['id']] = $row;
            $projects[$row['id']]['additional_info'] = [];
        }
        if (!empty($row['additional_info'])) {
            $projects[$row['id']]['additional_info'][] = htmlspecialchars($row['additional_info']);
        }
    }
}

$currentDateTime = date("Y-m-d H:i");

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'recent';
$filteredProjects = [];

switch ($filter) {
    case 'ongoing':
        $filteredProjects = array_filter($projects, function($project) use ($currentDateTime) {
            return $currentDateTime >= $project['project_date'] && $currentDateTime >= $project['project_time'];
        });
        break;

    case 'upcoming':
        $filteredProjects = array_filter($projects, function($project) use ($currentDateTime) {
            return $project['project_date'] > $currentDateTime;
        });
        break;

    case 'recent':
    default:
        $filteredProjects = array_filter($projects, function($project) {
            return strtotime($project['project_date']) >= strtotime('-7 days');
        });
        break;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom
    </title>
    <link rel="stylesheet" href="css/ad.css">
    <link rel="stylesheet" href="css/modal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
                <a href="admin_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
            </div>
            <nav>
                <div class="db">
                    <ul>
                        <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                            <a href="admin_dashboard.php" class="dashboard-link">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                            <div class="dropdown-content" id="options">
                                <ul>
                                    <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                                    <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                                </ul>
                            </div>
                        </li>
                        <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
                        <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
                        <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
                    </ul>
                </div>
            </nav>
            <a href="logout.php" class="logout">Log out</a>
        </aside>

        <main class="main-content">
            <header class="header">
                <h1>Projects</h1>
                <div class="profile"><p></p></div>
            </header>

            <section class="events-section">
                <div class="events-nav">
                    <button <?php echo ($filter == 'recent') ? 'class="active"' : ''; ?>><a href="?filter=recent">Recent Projects</a></button>
                    <button <?php echo ($filter == 'ongoing') ? 'class="active"' : ''; ?>><a href="?filter=ongoing">Ongoing Projects</a></button>
                    <button <?php echo ($filter == 'upcoming') ? 'class="active"' : ''; ?>><a href="?filter=upcoming">Upcoming Projects</a></button>
                    <button><a href="edit-projects.php">Add Project</a></button>
                </div>

                <div class="events-cards">  
                <?php if (empty($filteredProjects)): ?>  
                    <p>No events found.</p>
                <?php else: ?>  
                    <div class="event-list">  
                        <?php foreach ($filteredProjects as $project): ?>  
                            <div class="event-card" onclick="
                                openModal(
                                    '<?php echo addslashes($project['project_name']); ?>', 
                                    '<?php echo htmlspecialchars($project['project_date']); ?>',  
                                    '<?php echo htmlspecialchars($project['project_time']); ?>',  
                                    '<?php echo htmlspecialchars($project['project_type']); ?>',  
                                    '<?php echo htmlspecialchars($project['project_description']); ?>',
                                    '<?php echo htmlspecialchars(str_replace(' ', '%20', $project['project_image'])); ?>',  
                                    '<?php echo htmlspecialchars($project['project_location']); ?>',  
                                    '<?php echo htmlspecialchars($project['project_organizer']); ?>')">
                                <h2><?php echo htmlspecialchars($project['project_name']); ?></h2><br>
                                <p>Date: <?php echo htmlspecialchars($project['project_date']); ?></p>
                                <p>Time: <?php echo htmlspecialchars($project['project_time']); ?></p>
                                <p>Type: <?php echo htmlspecialchars($project['project_type']); ?></p>
                                <p>Description: <?php echo htmlspecialchars($project['project_description']); ?></p>
                                <?php if (!empty($event['additional_info'])): ?>
                                    <p>Additional Information:</p>
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">...
                                        <?php foreach ($project['additional_info'] as $info): ?>
                                            <li><?php echo htmlspecialchars($info); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                                <?php if (!empty($project['project_image'])): ?>
                                    <img src="<?php echo htmlspecialchars(str_replace(' ', '%20', $project['project_image'])); ?>" alt="<?php echo htmlspecialchars($project['project_name']); ?>" />
                                <?php else: ?>
                                    <p>No image available.</p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            

            <div id='projectModal' class='modal' style='display:none;'>  
                <div class='modal-content'>  
                    <span class='close' onclick='closeModal()'>&times;</span>  
                    <h2 id='modalProjectName'></h2>

                    <table class='breakdown-table'>  
                        <tbody>  
                            <tr><td id='modalProjectDate'></td></tr>
                            <tr><td id='modalProjectTime'></td></tr>
                            <tr><td id='modalProjectType'></td></tr>
                            <tr><td id='modalProjectDescription'></td></tr>
                            <tr><td id='modalProjectLocation'></td></tr>
                            <tr><td id='modalProjectOrganizer'></td></tr>
                        </tbody>
                        <br>
                    </table>
                    <br>
                    <button onclick="openBudgetModal()">See Budget Breakdown</button>
                    <img id='modalProjectImage' style='max-width: 100%; height: auto; margin-top: 20px;'><br>
                    <button onclick="openSurveyModal()">Take Survey</button>
                    <button onclick="openSponsorModal()">Sponsor/Donate</button>
                </div>  
            </div>

            <div id='budgetModal' class='modal' style='display:none;'>  
                <div class='modal-content'>  
                    <span class='close' onclick='closeBudgetModal()'>&times;</span>
                    <h2 id='budgetModalTitle'>Budget Breakdown</h2>
                    <table class='breakdown-table'>  
                        <tbody>
                            <tr><td>Total Budget:</td></tr>
                            <tr><td>Total Spent:</td></tr>
                            <tr><td>Additional Expenses:</td></tr>
                        </tbody>
                    </table>
                </div>  
            </div>

            <div id="surveyModal" class="modal" style="display:none;">  
                <div class="modal-content">  
                    <span class="close" onclick="closeSurveyModal()">&times;</span>  
                    <h2>Survey</h2>  
                    <form action="#" method='post'>  
                        <label for='surveyQuestion'>Your feedback:</label><br/>  
                        <input type='text' id='surveyQuestion' name='surveyQuestion' required /><br/>  
                        <input type='submit' value='Submit' />  
                    </form>  
                </div>  
            </div>

            <div id="sponsorModal" class="modal" style="display:none;">  
                <div class="modal-content">  
                    <span class="close" onclick="closeSponsorModal()">&times;</span>  
                    <h2>Sponsor/Donate</h2>  
                    <p>Gcash: 09691689364</p>   
                    <p>Maya: 09691689364</p>   
                </div>  
            </div>

        </section>
        
    </main>

</div>
    <script src="js/skreep.js"></script>
    <script src="js/modalz.js"></script>
    <script src="js/survey.js"></script>
    <script src="js/budget.js"></script>
</body>
</html>
