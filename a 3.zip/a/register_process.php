<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('db_connection.php');

date_default_timezone_set('Asia/Manila');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $middle_initial = substr($_POST['middle_initial'], 0, 5);
    $last_name = $_POST['last_name'];

    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $birthday = "$year-$month-$day";

    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $timestamp = date("Y-m-d H:i:s");

    if (isset($_POST['barangay_id'])) {
        $user_type = 'admin';
        $barangay_id = $_POST['barangay_id'];

        if (isset($_FILES['proof_id']) && $_FILES['proof_id']['error'] == UPLOAD_ERR_OK) {
            $proof_id_file = 'uploads/' . basename($_FILES['proof_id']['name']);
            if (!move_uploaded_file($_FILES['proof_id']['tmp_name'], $proof_id_file)) {
                echo "Error uploading proof of ID.";
                exit;
            }

            $sql_user = "INSERT INTO users (first_name, middle_initial, last_name, birthday, email, password, user_type, barangay_id, proof_of_id) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            if ($stmt_user = mysqli_prepare($conn, $sql_user)) {
                mysqli_stmt_bind_param($stmt_user, "sssssssss", 
                    $first_name, 
                    $middle_initial, 
                    $last_name, 
                    $birthday, 
                    $email, 
                    $password, 
                    $user_type, 
                    $barangay_id, 
                    $proof_id_file);

                if (!mysqli_stmt_execute($stmt_user)) {
                    echo "Error executing user insert: " . mysqli_stmt_error($stmt_user);
                    exit;
                }
                mysqli_stmt_close($stmt_user);
            } else {
                echo "Error preparing user statement: " . mysqli_error($conn);
                exit;
            }

            $sql_log = "INSERT INTO activity_log (first_name, email, timestamp) VALUES (?, ?, ?)";
            
            if ($stmt_log = mysqli_prepare($conn, $sql_log)) {
                mysqli_stmt_bind_param($stmt_log, "sss", 
                    $first_name,
                    $email,
                    $timestamp);

                if (!mysqli_stmt_execute($stmt_log)) {
                    echo "Error executing activity log insert: " . mysqli_stmt_error($stmt_log);
                    exit;
                }
                mysqli_stmt_close($stmt_log);
            } else {
                echo "Error preparing activity log statement: " . mysqli_error($conn);
                exit;
            }

        } else {
            echo "Error uploading proof of ID.";
            exit;
        }
    } else {
        $user_type = 'user';

        $sql_user = "INSERT INTO users (first_name, middle_initial, last_name, birthday, email, password, user_type) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)";

        if ($stmt_user = mysqli_prepare($conn, $sql_user)) {
            mysqli_stmt_bind_param($stmt_user, "sssssss", 
                $first_name,
                $middle_initial,
                $last_name,
                $birthday,
                $email,
                $password,
                $user_type);

            if (!mysqli_stmt_execute($stmt_user)) {
                echo "Error executing user insert: " . mysqli_stmt_error($stmt_user);
                exit;
            }
            mysqli_stmt_close($stmt_user);
        } else {
            echo "Error preparing user statement: " . mysqli_error($conn);
            exit;
        }

        $sql_log = "INSERT INTO activity_log (first_name, email, timestamp) VALUES (?, ?, ?)";
        
        if ($stmt_log = mysqli_prepare($conn, $sql_log)) {
            mysqli_stmt_bind_param($stmt_log, "sss", 
                $first_name,
                $email,
                $timestamp);

            if (!mysqli_stmt_execute($stmt_log)) {
                echo "Error executing activity log insert: " . mysqli_stmt_error($stmt_log);
                exit;
            }
            mysqli_stmt_close($stmt_log);
        } else {
            echo "Error preparing activity log statement: " . mysqli_error($conn);
            exit;
        }
    }

    header("Location: success.php");
    exit;

} else {
    echo "Invalid request method.";
}

mysqli_close($conn);
?>