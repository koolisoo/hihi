<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
}

require 'db_connection.php';

// Fetch only non-archived transactions
$query = "SELECT * FROM transactions WHERE is_archived = 0"; // Ensure this query is correct
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$transactions = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/transactions.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .additional-fields {
            margin-top: 10px;
        }
        .budget-display {
            margin-bottom: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
                <a href="admin_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
            </div>
            <nav>
                <div class="db">
                    <ul>
                        <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                            <a href="admin_dashboard.php" class="dashboard-link">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                            <div class="dropdown-content" id="options">
                                <ul>
                                    <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                                    <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                                </ul>
                            </div>
                        </li>
                        <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
                        <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
                        <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
                    </ul>
                </div>
            </nav>
            <a href="logout.php" class="logout">Log out</a>
        </aside>
        <main class="main-content">
            <header class="header">
                <h1>Transactions</h1>
            </header>

            <button class="addButton" id="addButton">Add</button>

            <table>
                <thead>
                    <tr>
                        <th>Authorized Official</th>
                        <th>Item</th>
                        <th>Date</th>
                        <th>Budget Given</th>
                        <th>Money Spent</th>
                        <th>Received By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($transactions) > 0): ?>
                        <?php foreach ($transactions as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['authorized_official']); ?></td>
                                <td><?php echo htmlspecialchars($row['item']); ?></td>
                                <td><?php echo htmlspecialchars($row['date']); ?></td>
                                <td><?php echo htmlspecialchars($row['budget']); ?></td>
                                <td><?php echo htmlspecialchars($row['money']); ?></td>
                                <td><?php echo htmlspecialchars($row['recipient']); ?></td>

                                <!-- Action Buttons -->
                                <td class="action-buttons">
                                    <!-- Print Button -->
                                    <button onclick="printReport('<?php echo htmlspecialchars($row['authorized_official']); ?>', '<?php echo htmlspecialchars($row['item']); ?>', '<?php echo htmlspecialchars($row['date']); ?>', '<?php echo htmlspecialchars($row['budget']); ?>', '<?php echo htmlspecialchars($row['money']); ?>', '<?php echo htmlspecialchars($row['receipt']); ?>')">Print</button>

                                    <!-- Delete Button -->
                                    <button onclick='archiveAndDeleteTransaction(<?php echo $row["id"]; ?>)'>Delete</button> 
                                </td> 
                            </tr> 
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan='7'>No transactions found.</td></tr> 
                    <?php endif; ?>
                </tbody> 
            </table>

            <div class="popup-form" id="popupForm">
    <h2>Transaction Report</h2>
    <form action="transactions-process.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="authorized_official">Authorized Official:</label>
            <input type="text" id="authorized_official" name="authorized_official" required placeholder="Enter Name:">
        </div>
        <div class="form-group">
            <label for="item">Item:</label>
            <input type="text" id="item" name="item" required placeholder="Enter item:">
        </div>
        <div class="form-group" id='additional_fields_container'>
        <button type='button' onclick='addAdditionalField()'>More Items</button>
        </div>
        <div class="form-group">
            <label for="date">Date:</label>
            <input type="text" id="date" name="date" required placeholder="Date: (Month/Day/Year)">
        </div>
        <div class="form-group">
            <label for="budget">Budget Given:</label>
            <input type="text" id="budget" name="budget" required placeholder="Budget Given:">
        </div>
        <div class="form-group">
            <label for="money">Money Spent:</label>
            <input type="text" id="money" name="money" required placeholder="Money Spent:">
        </div>
        <div class="form-group">
            <label for="recipient">Received By:</label>
            <input type="text" id="recipient" name="recipient" required placeholder="Received By:">
        </div>
        <div class="form-group">
            <label for="receipt">Receipt:</label>
            <input type="file" id="receipt" name="receipt" required placeholder="Receipt:">
        </div>
        <div class="form-group">
            <button type="submit" class="submit-button">Submit</button>
            <button type="button" id="closeButton" class="cancel-button">Close</button>
        </div>
    </form>
</div>

<div class="button-container">

                <button id="printAllButton">Print All Transactions</button>

                <div class="pagination-buttons">
                
                </div> 
            </div> 
        </main> 
    </div>

    <!-- Include JavaScript files -->
    <script src='js/skreep.js'></script> 
    <script src='js/transac-print.js'></script> 
    <script src='js/add.js'></script> 
    <script src='js/delete.js'></script> 
    <script>
        function addAdditionalField() {
             const container = document.getElementById("additional_fields_container");
             const newField = document.createElement("div");
             newField.className = "additional-fields";
             newField.innerHTML = `
                 <label for="additional_info[]">Additional Item:</label>
                 <input type="text" name="additional_item[]" placeholder="Enter additional item">
             `;
             container.appendChild(newField);
         }
    </script>
</body> 
</html>

<?php
$conn->close(); // Close the database connection
?>