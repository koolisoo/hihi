<?php
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'db_connection.php';

if (isset($_GET['authorized_official'])) {
    $id = intval($_GET['authorized_official']);
    
    $query = "DELETE FROM transactions WHERE authorized_official = ?";
    $stmt = $conn->prepare($query);
    
    if ($stmt) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: transactions.php?message=Transaction deleted successfully.");
            exit;
        } else {
            die("Error deleting transaction: " . $stmt->error);
        }
    } else {
        die("Error preparing statement: " . $conn->error);
    }
} else {
    die("Invalid request.");
}
?>