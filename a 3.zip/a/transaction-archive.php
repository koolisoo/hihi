<?php
session_start();
include('db_connection.php'); // Include your database connection file

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['id'])) {
    $id = $_GET['id']; // Use "id" directly

    // Fetch the transaction data to archive it
    $sql = "SELECT * FROM transactions WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $id);
    
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Execute failed: ' . $stmt->error]);
        exit();
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $transaction = $result->fetch_assoc();

        // Archive the transaction
        $archive_sql = "INSERT INTO archived_transactions (authorized_official, item, date, budget, money, recipient, receipt) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $archive_stmt = $conn->prepare($archive_sql);
        
        if (!$archive_stmt) {
            echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
            exit();
        }

        $archive_stmt->bind_param("sssdiss", 
            $transaction['authorized_official'], 
            $transaction['item'], 
            $transaction['date'], 
            $transaction['budget'], 
            $transaction['money'], 
            $transaction['recipient'], 
            $transaction['receipt']
        );

        if ($archive_stmt->execute()) {
            // Mark as archived instead of deleting
            $update_sql = "UPDATE transactions SET is_archived = 1 WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            
            if (!$update_stmt) {
                echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
                exit();
            }

            $update_stmt->bind_param("i", $id);
            
            if ($update_stmt->execute()) {
                echo json_encode(['success' => true]);
                exit();
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to mark transaction as archived.']);
                exit();
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to archive transaction.']);
            exit();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Transaction not found.']);
        exit();
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>