<?php
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/edit-events.css">
    <style>
        .additional-fields {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form action="process_edit-projects.php" method="POST" enctype="multipart/form-data">
        <button class="close"><a href="projectsforadmin.php">Close</a></button>
        
        <fieldset>
            <legend>Add New Project</legend>

            <label for="project_name">Project Name:</label>
            <input type="text" id="project_name" name="project_name" required>

            <label for="project_date">Project Date:</label>
            <input type="date" id="project_date" name="project_date" required>

            <label for="project_time">Project Time:</label>
            <input type="time" id="project_time" name="project_time" required>

            <label for="project_type">Project Type:</label>
            <select id="project_type" name="project_type" required onchange="toggleCustomInput()">
                <option value="">Select Project Type</option>
                <option value="Community Outreach">Community Outreach</option>
                <option value="Tree Planting">Tree Planting</option>
                <option value="Brgy. Fiesta">Brgy. Fiesta</option>
                <option value="Other">Other</option> 
            </select>

            <div id="custom_project_type_container" style="display:none;">
                <label for="custom_project_type">Please specify:</label>
                <input type="text" id="custom_project_type" name="custom_project_type">
            </div>

            <script>
                function toggleCustomInput() {
                    const select = document.getElementById("project_type");
                    const customInputContainer = document.getElementById("custom_project_type_container");
                    customInputContainer.style.display = select.value === "Other" ? "block" : "none";
                }

                function addAdditionalField() {
                    const container = document.getElementById("additional_fields_container");
                    const newField = document.createElement("div");
                    newField.className = "additional-fields";
                    newField.innerHTML = `
                        <label for="additional_info[]">Additional Info:</label>
                        <input type="text" name="additional_info[]" placeholder="Enter additional info">
                    `;
                    container.appendChild(newField);
                }
            </script>

            <label for="project_description">Project Description:</label>
            <textarea id="project_description" name="project_description" rows="4" required></textarea>

            <label for="project_location">Project Location:</label>
            <input type="text" id="project_location" name="project_location" required>

            <label for="project_organizer">Project Organizer:</label>
            <input type="text" id="project_organizer" name="project_organizer" required>

            <label for="project_image">Project Image:</label>
            <input type="file" id="project_image" name="project_image">

            <!-- Container for additional fields -->
            <div id="additional_fields_container"></div>

             <!-- Button to add additional fields -->
             <button type="button" onclick="addAdditionalField()">Add Additional Field</button><br>

         </fieldset>

         <input type="submit" value="Add Project">
     </form>
 </body>
</html>