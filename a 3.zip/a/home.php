<?php
require 'db_connection.php';

$query = "SELECT * FROM events ORDER BY event_date ASC";
$result = $conn->query($query);

$events = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/ad.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
                <a href="login.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
            </div>
            <nav>
                <div class="db">
                    <ul>
                        <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                            <a href="login.php" class="dashboard-link">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                            <div class="dropdown-content" id="options">
                                <ul>
                                    <li><a href="login.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                                    <li><a href="login.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <a href="logout.php" class="logout">Log out</a>
        </aside>

        <main class="main-content">
            <header class="header">
                <h1>Welcome</h1>
                <div class="profile"></div>
            </header>

            <section class="events-section">
                <div class="events-nav">
                    <button class="active"><a href="login.php">Recent Events</a></button>
                    <button><a href="login.php">Ongoing Events</a></button>
                    <button><a href="login.php">Upcoming Events</a></button>
                </div>
                <div class="events-cards">
                    <?php if (empty($events)): ?>
                        <p>No upcoming events and projects found.</p>
                    <?php else: ?>
                        <div class="event-list">
                        <?php foreach ($events as $event): ?>
                        <div class="event-card">
                        <a href="login.php" style="text-decoration: none; color: inherit;">
                        <h2><?php echo htmlspecialchars($event['event_name']); ?></h2>
                        <p>Date: <?php echo htmlspecialchars($event['event_date']); ?></p>
                        <p>Time: <?php echo htmlspecialchars($event['event_time']); ?></p>
                        <p>Type: <?php echo htmlspecialchars($event['event_type']); ?></p>
                        <p>Description: <?php echo htmlspecialchars($event['event_description']); ?></p>
                        <?php if (!empty($event['event_image'])): ?>
                            <img src="<?php echo htmlspecialchars($event['event_image']); ?>" alt="<?php echo htmlspecialchars($event['event_name']); ?>" />
                        <?php else: ?>
                            <p>No image available.</p>
                        <?php endif; ?>
                        </a>
                        </div>
                        <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </main>

    </div>

    <script src="js/skreep.js"></script>
    <script src="js/modals.js"></script>
    <script type="text/javascript">
        function showOptions() {
            document.getElementById("options").style.display = "block";
        }

        function hideOptions() {
            document.getElementById("options").style.display = "none";
        }
    </script>
</body>
</html>