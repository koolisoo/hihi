<?php
session_start();
if ($_SESSION['user_type'] !== 'user') {
    header("Location: login.php");
    exit;
}
require 'db_connection.php';

date_default_timezone_set('Asia/Manila');

$query = "
    SELECT e.*, a.info AS additional_info
    FROM events e
    LEFT JOIN event_additional_info a ON e.id = a.event_id
    ORDER BY e.event_date ASC
";
$result = $conn->query($query);

$events = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if (!isset($events[$row['id']])) {
            $events[$row['id']] = array_merge($row, ['additional_info' => []]);
        }
        if (!empty($row['additional_info'])) {
            array_push($events[$row['id']]['additional_info'], htmlspecialchars($row['additional_info']));
        }
    }
}

$currentDateTime = date("Y-m-d H:i");

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'recent';
$filteredEvents = [];

switch ($filter) {
    case 'ongoing':
        foreach ($events as &$event) {
            if ($currentDateTime >= "{$event['event_date']} {$event['event_time']}") {
                array_push($filteredEvents, $event);
            }
        }
        break;

    case 'upcoming':
        foreach ($events as &$event) {
            if ($event['event_date'] > date("Y-m-d")) {
                array_push($filteredEvents, $event);
            }
        }
        break;

    case 'recent':
    default:
        foreach ($events as &$event) {
            if (strtotime($event['event_date']) >= strtotime('-7 days')) {
                array_push($filteredEvents, $event);
            }
        }
        break;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/ad.css"> 
    <link rel="stylesheet" href="css/modal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="dashboard-container">
    <aside class="sidebar">
        <div class="logo">
            <a href="user_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
        </div>
        <nav>
            <div class="db">
                <ul>
                    <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                        <a href="user_dashboard.php" class="dashboard-link">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <div class="dropdown-content" id="options">
                            <ul>
                                <li><a href="eventsforusers.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                                <li><a href="projectsforusers.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                            </ul>
                        </div>
            </div>
        </nav>
        <a href="logout.php" class="logout">Log out</a>
    </aside>

    <main class="main-content">
        <header class="header">
            <h1>Events</h1>
            <div class="profile"><p></p></div>
        </header>

        <section class="events-section">
            <div class="events-nav">
                <button <?php echo ($filter == 'recent') ? 'class="active"' : ''; ?>><a href="?filter=recent">Recent Events</a></button>
                <button <?php echo ($filter == 'ongoing') ? 'class="active"' : ''; ?>><a href="?filter=ongoing">Ongoing Events</a></button>
                <button <?php echo ($filter == 'upcoming') ? 'class="active"' : ''; ?>><a href="?filter=upcoming">Upcoming Events</a></button>
            </div>

            <div class="events-cards">  
                <?php if (empty($filteredEvents)): ?>  
                    <p>No events found.</p>
                <?php else: ?>  
                    <div class="event-list">  
                        <?php foreach ($filteredEvents as $event): ?>  
                            <div class="event-card" onclick="
                                openModal(
                                    '<?php echo addslashes($event['event_name']); ?>', 
                                    '<?php echo htmlspecialchars($event['event_date']); ?>',  
                                    '<?php echo htmlspecialchars($event['event_time']); ?>',  
                                    '<?php echo htmlspecialchars($event['event_type']); ?>',  
                                    '<?php echo htmlspecialchars($event['event_description']); ?>',
                                    '<?php echo htmlspecialchars(str_replace(' ', '%20', $event['event_image'])); ?>',  
                                    '<?php echo htmlspecialchars($event['event_location']); ?>',  
                                    '<?php echo htmlspecialchars($event['event_organizer']); ?>')">
                                <h2><?php echo htmlspecialchars($event['event_name']); ?></h2><br>
                                <p>Date: <?php echo htmlspecialchars($event['event_date']); ?></p>
                                <p>Time: <?php echo htmlspecialchars($event['event_time']); ?></p>
                                <p>Type: <?php echo htmlspecialchars($event['event_type']); ?></p>
                                <p>Description: <?php echo htmlspecialchars($event['event_description']); ?></p>
                                <?php if (!empty($event['additional_info'])): ?>
                                    <p>Additional Information:</p>
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">...
                                        <?php foreach ($event['additional_info'] as $info): ?>
                                            <li><?php echo htmlspecialchars($info); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                                <?php if (!empty($event['event_image'])): ?>
                                    <img src="<?php echo htmlspecialchars(str_replace(' ', '%20', $event['event_image'])); ?>" alt="<?php echo htmlspecialchars($event['event_name']); ?>" />
                                <?php else: ?>
                                    <p>No image available.</p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            

            <div id='eventModal' class='modal' style='display:none;'>  
                <div class='modal-content'>  
                    <span class='close' onclick='closeModal()'>&times;</span>  
                    <h2 id='modalEventName'></h2>

                    <table class='breakdown-table'>  
                        <tbody>  
                            <tr><td id='modalEventDate'></td></tr>
                            <tr><td id='modalEventTime'></td></tr>
                            <tr><td id='modalEventType'></td></tr>
                            <tr><td id='modalEventDescription'></td></tr>
                            <tr><td id='modalEventLocation'></td></tr>
                            <tr><td id='modalEventOrganizer'></td></tr>
                        </tbody>
                        <br>
                    </table>
                    <br>
                    <button onclick="openBudgetModal()">See Budget Breakdown</button>
                    <img id='modalEventImage' style='max-width: 100%; height: auto; margin-top: 20px;'><br>
                    <button onclick="openSurveyModal()">Take Survey</button>
                    <button onclick="openSponsorModal()">Sponsor/Donate</button>
                </div>  
            </div>

            <div id='budgetModal' class='modal' style='display:none;'>  
                <div class='modal-content'>  
                    <span class='close' onclick='closeBudgetModal()'>&times;</span>
                    <h2 id='budgetModalTitle'>Budget Breakdown</h2>
                    <table class='breakdown-table'>  
                        <tbody>
                            <tr><td>Total Budget:</td></tr>
                            <tr><td>Total Spent:</td></tr>
                            <tr><td>Additional Expenses:</td></tr>
                        </tbody>
                    </table>
                </div>  
            </div>

            <div id="surveyModal" class="modal" style="display:none;">  
                <div class="modal-content">  
                    <span class="close" onclick="closeSurveyModal()">&times;</span>  
                    <h2>Survey</h2>  
                    <form action="#" method='post'>  
                        <label for='surveyQuestion'>Your feedback:</label><br/>  
                        <input type='text' id='surveyQuestion' name='surveyQuestion' required /><br/>  
                        <input type='submit' value='Submit' />  
                    </form>  
                </div>  
            </div>

            <div id="sponsorModal" class="modal" style="display:none;">  
                <div class="modal-content">  
                    <span class="close" onclick="closeSponsorModal()">&times;</span>  
                    <h2>Sponsor/Donate</h2>  
                    <p>Gcash: 09691689364</p>   
                    <p>Maya: 09691689364</p>   
                </div>  
            </div>

        </section>
        
    </main>

</div>

<script src="js/modals.js"></script>
<script src="js/skreep.js"></script>
<script src="js/budget.js"></script>
<script src="js/survey.js"></script>

<?php $conn->close();?>  

</body>
</html>