<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/syles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="right-section">

            <h2>CHOOSE ACCOUNT ROLE TO CREATE</h2>
            <div class="roles">
               
                <button class="role-button" class="open-modal-btn" onclick="openModal('official')">
                    <i class="fas fa-user-shield"></i> OFFICIAL
                </button>
                <button class="role-button" class="open-modal-btn" onclick="openModal('user')">
                    <i class="fas fa-user"></i> RESIDENT
                </button>
            </div>
            <p>Already have an account? <a href="login.php">Login Here.</a></p>
        </div>
    </div>

    <div id="official" class="modal">
    <div class="modal-content">
        <div class="form-header">
            <h1>Sign Up as Admin</h1>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form class="sign-up-form" action="register_process.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <input type="text" name="first_name" placeholder="First Name" required>
                <input type="text" name="middle_initial" placeholder="Middle Initial" required>
                <input type="text" name="last_name" placeholder="Last Name" required>
            </div>
            <div class="form-group">
                <select name="day" required>
                    <option value="">Day</option>
                    <?php for ($i = 1; $i <= 31; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
                <select name="month" required>
                    <option value="">Month</option>
                    <?php 
                    $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                    foreach ($months as $index => $month): ?>
                        <option value="<?= $index + 1 ?>"><?= $month ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="year" required>
                    <option value="">Year</option>
                    <?php 
                    $currentYear = date("Y");
                    for ($i = $currentYear; $i >= 1900; $i--): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="barangay_id" placeholder="Barangay ID" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class='form-group'>
                <input type='file' name='proof_id' accept='.jpg,.jpeg,.png' required>
            </div>
            <button type="submit">Sign Up</button>
        </form> 
    </div> 
</div>

<div id="user" class="modal">
    <div class="modal-content">
        <div class="form-header">
            <h1>Sign Up as User</h1>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form class="sign-up-form" action="register_process.php" method="POST">
            <div class="form-group">
                <input type="text" name="first_name" placeholder="First Name" required>
                <input type="text" name="middle_initial" placeholder="Middle Initial">
                <input type="text" name="last_name" placeholder="Last Name" required>
            </div>
            <div class="form-group">
                <select name="day" required>
                    <option value="">Day</option>
                    <?php for ($i = 1; $i <= 31; $i++): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
                <select name="month" required>
                    <option value="">Month</option>
                    <?php 
                    $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                    foreach ($months as $index => $month): ?>
                        <option value="<?= $index + 1 ?>"><?= $month ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="year" required>
                    <option value="">Year</option>
                    <?php 
                    $currentYear = date("Y");
                    for ($i = $currentYear; $i >= 1900; $i--): ?>
                        <option value="<?= $i ?>"><?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Sign Up</button>
        </form> 
    </div> 
</div>
    <script src="js/script.js"></script>
</body> 
</html> 