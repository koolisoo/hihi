<?php
session_start();
include('db_connection.php');

if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$query = "SELECT *
          FROM activity_log
          ORDER BY timestamp DESC";

$result = $conn->query($query);

if (!$result) {
    echo "Error fetching activity logs: " . mysqli_error($conn);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/activitylog.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
            <a href="admin_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
            </div>
            <nav>
    <div class="db">
        <ul>
            <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                <a href="admin_dashboard.php" class="dashboard-link">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <div class="dropdown-content" id="options">
                    <ul>
                        <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                        <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
            <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
        </ul>
    </div>
</nav>
            <a href="logout.php" class="logout">Log out</a>
        </aside>

        <main class="main-content">
            <header class="header">
                <h1>Activity Log</h1>
            </header>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['action']); ?></td>
                                <td><?php echo htmlspecialchars($row['timestamp']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">No activity logs found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </main>
    </div>

    <script src="js/skreep.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php
mysqli_close($conn);
?>
</body>
</html>