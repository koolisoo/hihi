function archiveAndDeleteTransaction(id) {
    if (confirm("Are you sure you want to delete this transaction? This action will archive it.")) {
        fetch(`transaction-archive.php?id=${id}`)
            .then(response => {
                // Check if response is ok (status in the range 200-299)
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); // Parse JSON from response
            })
            .then(data => {
                if (data.success) {
                    alert("Transaction archived and deleted successfully.");
                    location.reload(); // Reload the page to see changes
                } else {
                    alert("Error: " + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred while processing your request: " + error.message);
            });
    }
}