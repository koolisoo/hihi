function openModal(role) {
    if (role === 'official') {
      document.getElementById('official').style.display = 'block';
    } else if (role === 'user') {
      document.getElementById('user').style.display = 'block';
    }
  }
  
  function closeModal() {
    document.getElementById('official').style.display = 'none';
    document.getElementById('user').style.display = 'none';
  }
  
  function validateForm(role) {
    const form = document.getElementById('modal');
    const firstName = form.elements.firstName;
    const lastName = form.elements.lastName;
    const email = form.elements.email;
    const password = form.elements.password;
    const confirmPassword = form.elements.confirmPassword;
    const barangayId = form.elements.barangayId;
    form.submit();
    return true;
  }