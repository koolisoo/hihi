function printAllTransactions() {
    const table = document.getElementById('transactionsTable');
    const newWindow = window.open('', '_blank');

    newWindow.document.write('<html><head><title>Print Transactions</title>');
    newWindow.document.write('<link rel="stylesheet" type="text/css" href="transactions.css">'); // Include your CSS
    newWindow.document.write('</head><body>');
    newWindow.document.write('<h1>Transactions Report</h1>');
    
    // Include any relevant images if needed
    newWindow.document.write('<img src="path/to/your/image.jpg" alt="Logo" style="width:100px;height:auto;">'); // Example image
    
    newWindow.document.write(table.outerHTML); // Add the table HTML
    newWindow.document.write('</body></html>');

    newWindow.document.close(); // Close the document
    newWindow.print(); // Trigger print dialog
}

function printReport(official, item, date, budget, money, receiptPath) {
    // Prepare a temporary section for printing
    const printContent = `
        <h1>Transaction Report</h1>
        <br>
        <p>Authorized Official: ${official}</p>
        <br>
        <p>Item: ${item}</p>
        <br>
        <p>Date: ${date}</p>
        <br>
        <p>Budget Given: ${budget}</p>
        <br>
        <p>Money Spent: ${money}</p>
        <br>
        <img src="${receiptPath}" alt="Receipt" style="max-width: 80%; height: auto;">
    `;
    
    // Create a new window for printing
    const newWindow = window.open('', '_blank');
    newWindow.document.write('<html><head><title>Print Transaction Report</title>');
    newWindow.document.write('<link rel="stylesheet" type="text/css" href="transactions.css">'); // Include your CSS
    newWindow.document.write('</head><body>');
    newWindow.document.write(printContent);
    newWindow.document.write('</body></html>');
    
    newWindow.document.close(); // Close the document
    newWindow.print(); // Trigger print dialog
}