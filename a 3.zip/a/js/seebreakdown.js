function seeBreakdown() {
    // Assuming you have access to budget data when opening the modal
    const budget = document.getElementById('modalEventBudget').innerText; // Get budget
    const spent = document.getElementById('modalEventSpent').innerText; // Get spent amount

    // Populate budget details
    document.getElementById('modalEventBudget').innerText = budget || "Not Available";
    document.getElementById('modalEventSpent').innerText = spent || "Not Available";

    // Show modal
    document.getElementById('eventModal').style.display = 'block';
}