document.getElementById('addButton').addEventListener('click', function() {
    document.getElementById('popupForm').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
});

document.getElementById('closeButton').addEventListener('click', function() {
    document.getElementById('popupForm').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
});

document.getElementById('reportForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const category = document.getElementById('category').value;
    const month = document.getElementById('month').value;

    console.log("Category:", category);
    console.log("Month:", month);

    document.getElementById('popupForm').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';

    this.reset();
});