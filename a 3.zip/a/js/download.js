// Add event listeners to all download buttons
document.querySelectorAll('.downloadButton').forEach(button => {
    button.addEventListener('click', function() {
        const category = this.getAttribute('data-category');
        const month = this.getAttribute('data-month');
        
        // Call the download function
        downloadReport(category, month);
    });
});

// Function to handle report download
function downloadReport(category, month) {

    // Create content for the report
    const reportContent = `Report Details:\nCategory: ${category}\nMonth: ${month}  budget: ${budget}`;

    const filename = `${category}_${month}_report.txt`; // Specify filename based on category and month


    //to pdf



    //select budget events where data like == $month;

    
    $budget 




    // 




    
    // Create a new Blob object using the text
    const blob = new Blob([reportContent], { type: 'text/plain' });
    
    // Create a link element
    const link = document.createElement('a');
    
    // Set the URL using createObjectURL
    link.href = window.URL.createObjectURL(blob);
    
    // Set the download attribute
    link.download = filename;

    // Append link to body and trigger click
    document.body.appendChild(link);
    link.click();
    
    // Clean up and remove the link
    document.body.removeChild(link);
}