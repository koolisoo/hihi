function openSurveyModal() {
    document.getElementById('surveyModal').style.display = 'block';
}

function closeSurveyModal() {
    document.getElementById('surveyModal').style.display = 'none';
}

function openSponsorModal() {
    document.getElementById('sponsorModal').style.display = 'block';
}

function closeSponsorModal() {
    document.getElementById('sponsorModal').style.display = 'none';
}

window.onclick = function(event) {
    const surveyModal = document.getElementById('surveyModal');
    const sponsorModal = document.getElementById('sponsorModal');
    
    if (event.target == surveyModal) {
        closeSurveyModal();
    } else if (event.target == sponsorModal) {
        closeSponsorModal();
    }
}