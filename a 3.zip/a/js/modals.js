function openModal(name, date, time, type, description, image, location, organizer) {

    // Set modal content for event details
    document.getElementById('modalEventName').innerText = name;
    document.getElementById('modalEventDate').innerText = "Date: " + date;
    document.getElementById('modalEventTime').innerText = "Time: " + time;
    document.getElementById('modalEventType').innerText = "Type: " + type;
    document.getElementById('modalEventDescription').innerText = "Description: " + description;
    document.getElementById('modalEventLocation').innerText = "Location: " + location;
    document.getElementById('modalEventOrganizer').innerText = "Organizer: " + organizer;
    // Set the modal image
    const modalImage = document.getElementById('modalEventImage');
    modalImage.src = image ? decodeURIComponent(image) : '';

    // Show the event modal
    document.getElementById("eventModal").style.display = "block";
}
function closeModal() {
    document.getElementById("eventModal").style.display = "none";
}