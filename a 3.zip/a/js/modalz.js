function openModal(name, date, time, type, description, image, location, organizer) {
    document.getElementById('modalProjectName').innerText = name;
    document.getElementById('modalProjectDate').innerText = "Date: " + date;
    document.getElementById('modalProjectTime').innerText = "Time: " + time;
    document.getElementById('modalProjectType').innerText = "Type: " + type;
    document.getElementById('modalProjectDescription').innerText = "Description: " + description;
    document.getElementById('modalProjectLocation').innerText = "Location: " + location;
    document.getElementById('modalProjectOrganizer').innerText = "Organizer: " + organizer;

    const modalImage = document.getElementById('modalProjectImage');
    modalImage.src = image ? decodeURIComponent(image) : '';

    // Show the modal
    document.getElementById("projectModal").style.display = "block";
}

function closeModal() {
    document.getElementById("projectModal").style.display = "none";
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const projectModal = document.getElementById('projectModal');
    
    // Check if the clicked target is the modal itself (the overlay)
    if (event.target === projectModal) {
        closeModal();
    }
}