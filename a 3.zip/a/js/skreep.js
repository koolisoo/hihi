function showOptions() {
    var optionsDiv = document.getElementById("options");
    optionsDiv.style.display = "block";
}

function hideOptions() {
    var optionsDiv = document.getElementById("options");
    optionsDiv.style.display = "none";
}