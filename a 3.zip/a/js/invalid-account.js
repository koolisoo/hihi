function closeModal() {
    document.getElementById('errorModal').style.display = "none";
    document.getElementById('successModal').style.display = "none";
}

// Optional: Close modal when clicking outside of it
window.onclick = function(event) {
    const errorModal = document.getElementById('errorModal');
    const successModal = document.getElementById('successModal');
    
    if (event.target === errorModal) {
        closeModal();
    }
    
    if (event.target === successModal) {
        closeModal();
    }
};