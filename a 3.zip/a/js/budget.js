function openBudgetModal() {
   const budgetDisplay = document.getElementById('budgetDisplay').value; // Get value from input
   const totalSpentDisplay = document.getElementById('totalSpentDisplay').value; // Get value from input

   // Call the modal function with actual values
   document.getElementById('budgetDisplay').innerText = budgetDisplay; // Update modal display
   document.getElementById('totalSpentDisplay').innerText = totalSpentDisplay; // Update modal display

   document.getElementById('budgetModal').style.display = 'block'; // Show modal
}
function closeBudgetModal(){
   document.getElementById('budgetModal').style.display = 'none';
}