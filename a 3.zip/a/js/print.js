function printReport(category, month) {
    var printableContent = `
        <h2>Report Details</h2>
        <p>Category: ${category}</p>
        <p>Month: ${month}</p>
    `;

    var printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Print Report</title>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printableContent);
    printWindow.document.write('</body></html>');

    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
}

document.getElementById('printAllButton').addEventListener('click', function() {
    var allReports = '';
    
    document.querySelectorAll('tbody tr').forEach(function(row) {
        var category = row.cells[0].innerText;
        var month = row.cells[1].innerText;
        
        allReports += `
            <h2>Report Details</h2>
            <p>Category: ${category}</p>
            <p>Month: ${month}</p><hr/>
        `;
    });

    var printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Print All Reports</title>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(allReports);
    printWindow.document.write('</body></html>');

    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
});