<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/style11.css">
</head>
<body>
    <section class="comm-login">
        <div class="wrapper">
            <div class="login-login">
                <form action="login_process.php" method="post">
                    <h2>LOG IN</h2>
                    <br><br>
                    <input type="email" name="email" placeholder="Email" required value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">
                    <input type="password" name="password" placeholder="Password" required value="">
                    <br><br>
                    <button type="submit" name="submit">LOG IN</button>
                    <h4><a href="forgot_password.php" style="color: black;">Forgot Password?</a></h4>
                    <br>
                    <p>Don't have an account? <a href="register.php">Sign up now.</a></p>
                </form>
            </div>
        </div>
    </section>
    <?php if (isset($_GET['error'])) : ?>
    <div id="errorModal" class="modal" style="display:block;">
        <div class="modal-content">
            <p>Invalid email or password. Please try again.</p>
            <button onclick="closeModal()">Okay</button> 
        </div>
    </div>
    <?php endif; ?>

    <script src="js/invalid-account.js"></script>

</body>
</html>