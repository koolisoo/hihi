<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'db_connection.php';

date_default_timezone_set('Asia/Manila');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo '<pre>';
    print_r($_POST); // This will show you all the data sent in the POST request
    echo '</pre>';
    $name = isset($_POST['event_name']) ? trim($_POST['event_name']) : '';
    $date = isset($_POST['event_date']) ? trim($_POST['event_date']) : '';
    $time = isset($_POST['event_time']) ? trim($_POST['event_time']) : '';
    $type = isset($_POST['event_type']) ? trim($_POST['event_type']) : '';
    $description = isset($_POST['event_description']) ? trim($_POST['event_description']) : '';
    $location = isset($_POST['event_location']) ? trim($_POST['event_location']) : '';
    $organizer = isset($_POST['event_organizer']) ? trim($_POST['event_organizer']) : '';

    $budgetDisplay = isset($_POST['budgetDisplay']) ? $_POST['budgetDisplay'] : null;
    $totalSpentDisplay = isset($_POST['totalSpentDisplay']) ? $_POST['totalSpentDisplay'] : null;


    // Initialize image path
    $imagePath = null;

    if ($budgetDisplay === null || $totalSpentDisplay === null) {
        die("Error: budgetDisplay or totalSpentDisplay is missing.");
    }

    if (isset($_FILES['event_image'])) {
        if ($_FILES['event_image']['error'] === UPLOAD_ERR_OK) {
            $targetDir = 'uploads/';
            $fileName = basename($_FILES["event_image"]["name"]);
            $targetFilePath = $targetDir . $fileName;

            if (move_uploaded_file($_FILES["event_image"]["tmp_name"], $targetFilePath)) {
                $imagePath = $targetFilePath;
            } else {
                echo "Error moving uploaded file.";
                exit();
            }
        } else {
            switch ($_FILES['event_image']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    echo "The uploaded file exceeds the upload_max_filesize directive in php.ini.";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    echo "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    echo "The uploaded file was only partially uploaded.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    echo "No file was uploaded.";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    echo "Missing a temporary folder.";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    echo "Failed to write file to disk.";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    echo "A PHP extension stopped the file upload.";
                    break;
                default:
                    echo "Unknown upload error.";
                    break;
            }
            exit();
        }
    }

    // Insert into events table
    $stmt = $conn->prepare("INSERT INTO events (event_name, event_date, event_time, event_type, event_description, event_image, event_location, event_organizer, budgetDisplay, totalSpentDisplay) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ssssssssss", $name, $date, $time, $type, $description, $imagePath, $location, $organizer, $budgetDisplay, $totalSpentDisplay);
        
        if ($stmt->execute()) {
            // Get the last inserted ID to use for additional expenses
            $last_id = $stmt->insert_id;

            // Insert additional expenses if any
            if (!empty($_POST['additional_expenses'])) {
                foreach ($_POST['additional_expenses'] as $expense) {
                    if (!empty($expense)) {
                        // Directly use the expense amount since no description is needed
                        $amount = floatval(trim($expense));
                        
                        // Prepare statement for additional expenses
                        $info_stmt = $conn->prepare("INSERT INTO additional_expenses (event_id, expense_amount) VALUES (?, ?)");
                        if ($info_stmt) {
                            // Bind parameters
                            $info_stmt->bind_param("id", $last_id, $amount);
                            if (!$info_stmt->execute()) {
                                die("Error adding additional expense: " . $info_stmt->error);
                            }
                            $info_stmt->close();
                        } else {
                            die("Error preparing additional expense statement: " . $conn->error);
                        }
                    }
                }
            }

            if (!empty($_POST['additional_info'])) {
                foreach ($_POST['additional_info'] as $additional_info) {
                    if (!empty($additional_info)) {
                        // Prepare statement for inserting additional info
                        $info_stmt = $conn->prepare("INSERT INTO event_additional_info (event_id, info) VALUES (?, ?)");
                        if ($info_stmt) {
                            // Ensure last_id is valid and defined
                            $info_stmt->bind_param("is", $last_id, trim($additional_info));
                            if (!$info_stmt->execute()) {
                                die("Error adding additional info: " . $info_stmt->error);
                            }
                            $info_stmt->close();
                        } else {
                            die("Error preparing additional info statement: " . $conn->error);
                        }
                    }
                }
            }

            // Close the main event statement and redirect
            $stmt->close();
            header("Location: eventsforadmin.php");
            exit();
        } else {
            die("Error adding event: " . $stmt->error);
        }
    } else {
        die("Error preparing statement: " . $conn->error);
    }
}