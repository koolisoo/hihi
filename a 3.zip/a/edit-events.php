<?php
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}
require 'db_connection.php';
$event = [
    'budgetDisplay' => 1000.00, // Set this to a test value
    'totalSpentDisplay' => 200.00 // Set this to a test value
];

// Debugging output
echo "<pre>";
print_r($event); // Check what values are being set
echo "</pre>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/edit-events.css">
    <style>
        .additional-fields {
            margin-top: 10px;
        }
        .budget-display {
            margin-bottom: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <form action="process_edit-events.php" method="POST" enctype="multipart/form-data">
        
        <div class="close"><a href="eventsforadmin.php">Close</a></div> <!-- Close button moved here -->
        
        <fieldset>
            <legend>Add New Event</legend>

            <label for="event_name">Event Name:</label>
            <input type="text" id="event_name" name="event_name" required>

            <label for="event_date">Event Date:</label>
            <input type="date" id="event_date" name="event_date" required>

            <label for="event_time">Event Time:</label>
            <input type="time" id="event_time" name="event_time" required>

            <label for="event_type">Event Type:</label>
            <select id="event_type" name="event_type" required onchange="toggleCustomInput()">
                <option value="">Select Event Type</option>
                <option value="Community Outreach">Community Outreach</option>
                <option value="Tree Planting">Tree Planting</option>
                <option value="Brgy. Fiesta">Brgy. Fiesta</option>
                <option value="Other">Other</option> 
            </select>

            <div id="custom_event_type_container" style="display:none;">
                <label for="custom_event_type">Please specify:</label>
                <input type="text" id="custom_event_type" name="custom_event_type">
            </div>

            <label for="event_description">Event Description:</label>
            <textarea id="event_description" name="event_description" rows="4" required></textarea>

            <label for="event_location">Event Location:</label>
            <input type="text" id="event_location" name="event_location" required>

            <label for="event_organizer">Event Organizer:</label>
            <input type="text" id="event_organizer" name="event_organizer" required>

            <label for="event_image">Event Image:</label>
            <input type="file" id="event_image" name="event_image">
            
             <div id='additional_info'></div>
             <button type='button' onclick='addAdditionalField()'>Add Additional Information</button><br><br>

             <div class='budget-display'>
                 Budget: 
                 PHP<span id='budget'><?php echo number_format($event['budgetDisplay'], 2); ?></span><br>

                 Total Spent: 
                 PHP<span id='total'><?php 
                     // Directly display total spent
                     echo number_format($event['totalSpentDisplay'], 2); 
                 ?></span><br>

                 Remaining: 
                 PHP<span id='remaining'><?php 
                     // Calculate remaining budget
                     $budgetDisplay = isset($event['budgetDisplay']) ? (float)$event['budgetDisplay'] : 0.0;
                     $totalSpentDisplay = isset($event['totalSpentDisplay']) ? (float)$event['totalSpentDisplay'] : 0.0;

                     // Calculate remaining budget
                     $remainingDisplay = $budgetDisplay - $totalSpentDisplay;
                     echo number_format($remainingDisplay, 2); // Display formatted remaining amount
                 ?></span> 
                 <br><br>
             </div>

             <label for='inputBudget'>Enter Budget:</label><br/>
             <input type='number' id='inputBudget' name='budgetDisplay' value='<?php echo $event["budgetDisplay"]; ?>' oninput='updateBudgetDisplays()' required /><br/><br/>

             <label for='inputTotalSpent'>Enter Total Spent:</label><br/>
             <input type='number' id='inputTotalSpent' name='totalSpentDisplay' value='<?php echo $event["totalSpentDisplay"]; ?>' oninput='updateBudgetDisplays()' required /><br/><br/>

             <!-- Additional Expenses Section -->
             <div class='additional-expenses' id='additional_expenses_container'>
                 <button type='button' onclick='addAdditionalExpense()'>Add Additional Expenses</button><br><br>
             </div>

         </fieldset>

         <!-- Submit button -->
         <input type='submit' value='Add Event'>
     </form>

     <!-- JavaScript Section -->
     <script>
         function updateBudgetDisplays() {
             // Get current values from input fields
             const budget = parseFloat(document.getElementById('inputBudget').value) || 0;
             const totalSpent = parseFloat(document.getElementById('inputTotalSpent').value) || 0;

             // Calculate total additional expenses
             const additionalExpenses = Array.from(document.querySelectorAll('input[name^=additional_expenses]'))
                 .reduce((sum, input) => sum + (parseFloat(input.value) || 0), 0);

             // Calculate remaining budget
             const remaining = budget - (totalSpent + additionalExpenses);

             // Update the display for remaining
             document.getElementById('remaining').innerText = remaining.toFixed(2);
             
             // Update total spent display
             document.getElementById('total').innerText = (totalSpent + additionalExpenses).toFixed(2);
         }

         function toggleCustomInput() {
             const select = document.getElementById("event_type");
             const customInputContainer = document.getElementById("custom_event_type_container");
             customInputContainer.style.display = select.value === "Other" ? "block" : "none";
         }

         function addAdditionalField() {
             const container = document.getElementById("additional_info");
             const newField = document.createElement("div");
             newField.className = "additional_info";
             newField.innerHTML = `
                 <label for="additional_info[]">Additional Info:</label>
                 <input type="text" name="additional_info[]" placeholder="Enter additional info">
             `;
             container.appendChild(newField);
         }

         function addAdditionalExpense() {
             const container = document.getElementById("additional_expenses_container");
             const newExpenseField = document.createElement("div");
             newExpenseField.className = "additional-fields";
             newExpenseField.innerHTML = `
                 <label for="additional_expenses[]">Additional Expense:</label>
                 <input type="number" name="additional_expenses[]" placeholder="Enter additional expense" oninput='updateBudgetDisplays()'>
             `;
             container.appendChild(newExpenseField);
         }
     </script>
 </body>
</html>