<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful</title>
    <link rel="stylesheet" href="css/success.css">
</head>
<body>
    <div class="container">
        <h1>Registration Successful!</h1>
        <br>
        <p>Thank you for registering!</p>
        <p>Your account has been created successfully.</p>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="success-message">
                <h3><?php echo $_SESSION['success']; ?></h3>
                <?php unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        <br>
        <br>
        <button><a href="login.php">Log in here.</a></button>
        <br>
    </div>
</body>
</html>