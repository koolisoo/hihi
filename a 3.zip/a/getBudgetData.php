<?php
header('Content-Type: application/json');

$hostname = "localhost";
$username = "root";
$password = "";
$database = "user_management";

$conn = new mysqli($hostname, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
    echo json_encode(['error' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Get the event ID from the AJAX request
$eventId = intval($_GET['event_id']);

// Prepare and execute the SQL query for budget information
$sql_budget = "SELECT budgetDisplay, totalSpentDisplay FROM budget WHERE event_id = ?";
$stmt_budget = $conn->prepare($sql_budget);
$stmt_budget->bind_param("i", $eventId);
$stmt_budget->execute();
$result_budget = $stmt_budget->get_result();

$data = [];
if ($row_budget = $result_budget->fetch_assoc()) {
    $data['budget'] = $row_budget['budgetDisplay'];
    $data['total_spent'] = $row_budget['totalSpentDisplay'];
}

// Prepare and execute the SQL query for additional expenses
$sql_expenses = "SELECT expense_amount, description FROM additional_expenses WHERE budget_id IN (SELECT id FROM budget WHERE event_id = ?)";
$stmt_expenses = $conn->prepare($sql_expenses);
$stmt_expenses->bind_param("i", $eventId);
$stmt_expenses->execute();
$result_expenses = $stmt_expenses->get_result();

$data['additional_expenses'] = [];
while ($row_expense = $result_expenses->fetch_assoc()) {
    $data['additional_expenses'][] = [
        'amount' => $row_expense['expense_amount'],
        'description' => $row_expense['description']
    ];
}

echo json_encode($data);

$stmt_budget->close();
$stmt_expenses->close();
$conn->close();
?>