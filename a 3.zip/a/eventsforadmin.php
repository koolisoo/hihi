<?php 
session_start(); 

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') { 
    header("Location: login.php"); 
    exit; 
} 

require 'db_connection.php'; 
date_default_timezone_set('Asia/Manila'); 

$query = "
    SELECT e.*, a.info AS additional_info, ae.expense_amount AS expense_amount  
    FROM events e 
    LEFT JOIN event_additional_info a ON e.id = a.event_id 
    LEFT JOIN additional_expenses ae ON e.id = ae.event_id  
    ORDER BY e.event_date ASC
"; 

$result = $conn->query($query); 
$events = []; 

if ($result && $result->num_rows > 0) { 
    while ($row = $result->fetch_assoc()) { 
        // Initialize event if not already done
        if (!isset($events[$row['id']])) { 
            $events[$row['id']] = array_merge($row, ['additional_info' => [], 'additional_expenses' => []]); 
        } 
        
        // Collect additional info
        if (!empty($row['additional_info'])) { 
            array_push($events[$row['id']]['additional_info'], htmlspecialchars($row['additional_info'])); 
        }
        
        // Collect additional expenses
        if (!empty($row['expense_amount'])) {
            array_push($events[$row['id']]['additional_expenses'], floatval($row['expense_amount']));
        }
    } 
} 

$currentDateTime = date("Y-m-d H:i"); 

// Filter events based on user selection
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'recent'; 
$filteredEvents = []; 

switch ($filter) { 
    case 'ongoing':
        foreach ($events as &$event) { 
            if ($currentDateTime >= "{$event['event_date']} {$event['event_time']}") { 
                array_push($filteredEvents, $event); 
            } 
        } 
        break; 
        
    case 'upcoming':
        foreach ($events as &$event) { 
            if ($event['event_date'] > date("Y-m-d")) { 
                array_push($filteredEvents, $event); 
            } 
        } 
        break; 
        
    case 'recent':
    default:  
        foreach ($events as &$event) { 
            if (strtotime($event['event_date']) >= strtotime('-7 days')) { 
                array_push($filteredEvents, $event); 
            } 
        } 
        break; 
} 

?>

<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Liquidation Loom</title> 
    <link rel="stylesheet" href="css/ad.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> 

    <style>
        /* Your existing styles */
        .modal-button {
            background-color: #007bff; /* Base color from system */
            border: none;
            color: white;
            padding: 5px 10px; /* Smaller padding */
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 12px; /* Smaller font size */
            margin: 5px 2px;
            cursor: pointer;
            border-radius: 4px;
        }

        .modal-button:hover {
            background-color: #0056b3; /* Darker shade for hover effect */
        }

        /* Modal Styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto; /* Center modal */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Smaller width of the modal */
            max-width: 500px; /* Maximum width for better appearance */
            height: auto; /* Automatic height based on content */
            max-height: 90%; /* Maximum height to prevent overflow */
            overflow-y: auto; /* Enable vertical scroll if needed */
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .breakdown-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }

        .breakdown-table th, .breakdown-table td {
          border: 1px solid #ddd;
          padding: 8px;
          text-align: left;
        }

        .breakdown-table th {
          background-color: #f2f2f2; /* Light gray for headers */
          font-weight: bold;
        }
    </style>
</head> 

<body> 

<div class="dashboard-container"> 

    <aside class="sidebar"> 
        <div class="logo"> <a href="admin_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a> </div> 
        
        <nav> 
            <div class="db"> 
                <ul> 
                    <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()"> 
                        <a href="admin_dashboard.php" class="dashboard-link"> <i class="fas fa-tachometer-alt"></i> Dashboard </a> 
                        <div class="dropdown-content" id="options"> 
                            <ul> 
                                <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li> 
                                <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li> 
                            </ul> 
                        </div>
                    </li>
                    <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
                    <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
                    <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
                </ul>
            </div>
        </nav>

        <a href="logout.php" class="logout">Log out</a> 

    </aside>

    <main class="main-content"> 

        <header class="header"> <h1>Events</h1> <div class="profile"><p></p></div> </header>

        <section class="events-section"> 

            <div class="events-nav">  
                <button <?php echo ($filter == 'recent') ? 'class="active"' : ''; ?>><a href="?filter=recent">Recent Events</a></button>
                <button <?php echo ($filter == 'ongoing') ? 'class="active"' : ''; ?>><a href="?filter=ongoing">Ongoing Events</a></button>
                <button <?php echo ($filter == 'upcoming') ? 'class="active"' : ''; ?>><a href="?filter=upcoming">Upcoming Events</a></button>
                <button><a href="edit-events.php">Add Event</a></button>
            </div>

            <div class="events-cards">  
    <?php if (empty($filteredEvents)): ?>  
        <p>No events found.</p>
    <?php else: ?>  
        <div class="event-list">  
            <?php foreach ($filteredEvents as $event): ?>  
                <div class="event-card" onclick="
                    openModal(
                        '<?php echo addslashes($event['event_name']); ?>', 
                        '<?php echo htmlspecialchars($event['event_date']); ?>',  
                        '<?php echo htmlspecialchars($event['event_time']); ?>',  
                        '<?php echo htmlspecialchars($event['event_type']); ?>',  
                        '<?php echo htmlspecialchars($event['event_description']); ?>',
                        '<?php echo htmlspecialchars(str_replace(' ', '%20', $event['event_image'])); ?>',  
                        '<?php echo htmlspecialchars($event['event_location']); ?>',  
                        '<?php echo htmlspecialchars($event['event_organizer']); ?>',
                    )">
                    <h2><?php echo htmlspecialchars($event['event_name']); ?></h2><br>
                    <p>Date: <?php echo htmlspecialchars($event['event_date']); ?></p>
                    <p>Time: <?php echo htmlspecialchars($event['event_time']); ?></p>
                    <p>Type: <?php echo htmlspecialchars($event['event_type']); ?></p>
                    <p>Description: <?php echo htmlspecialchars($event['event_description']); ?></p>

                    <?php if (!empty($event['additional_info'])): ?>
                        <p>Additional Information:</p>
                        <ul style="list-style-type: none; padding: 0; margin: 0;">
                            <?php foreach ($event['additional_info'] as $info): ?>
                                <li><?php echo htmlspecialchars($info); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                    <?php if (!empty($event['event_image'])): ?>
                        <img src="<?php echo htmlspecialchars(str_replace(' ', '%20', $event['event_image'])); ?>" alt="<?php echo htmlspecialchars($project['project_name']); ?>" />
                    <?php else: ?>
                        <p>No image available.</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div id='eventModal' class='modal' style='display:none;'>
    <div class='modal-content'>
        <span class='close' onclick='closeModal()'>&times;</span>
        <h2 id='modalEventName'></h2>
        <table class='breakdown-table'>
            <tbody>
                <tr><td id='modalEventDate'></td></tr>
                <tr><td id='modalEventTime'></td></tr>
                <tr><td id='modalEventType'></td></tr>
                <tr><td id='modalEventDescription'></td></tr>
                <tr><td id='modalEventLocation'></td></tr>
                <tr><td id='modalEventOrganizer'></td></tr>
            </tbody>
        </table>
        <button onclick="openBudgetModal()">See Budget Breakdown</button>
        <img id='modalEventImage' style='max-width: 100%; height: auto; margin-top: 20px;'>
        <button onclick="openSurveyModal()">Take Survey</button>
        <button onclick="openSponsorModal()">Sponsor/Donate</button>
    </div>  
</div>

<!-- Budget Modal -->
<div id='budgetModal' class='modal' style='display:none;'>  
    <div class='modal-content'>  
        <span class='close' onclick='closeBudgetModal()'>&times;</span>
        <h2 id='budgetModalTitle'>Budget Breakdown</h2>
        <table class='breakdown-table'>  
            <tbody id="budgetTableBody">
                <?php foreach ($filteredEvents as $event): ?>
                    <!-- Assuming budgetDisplay and totalSpentDisplay are part of the event data -->
                    <?php if (isset($event['budgetDisplay']) && isset($event['totalSpentDisplay'])) : ?>
                        <tr><td><strong>Total Budget:</strong> PHP <span id="budgetDisplay"><?php echo htmlspecialchars(number_format($event['budgetDisplay'], 2)); ?></span></td></tr>
                        <tr><td><strong>Additional Expenses:</strong></td></tr>
                        <?php if (!empty($event['additional_expenses'])): ?>
                            <?php foreach ($event['additional_expenses'] as $expense): ?>
                                <tr><td>- PHP <?php echo htmlspecialchars(number_format($expense, 2)); ?></td></tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td>- PHP 0.00</td></tr> <!-- Display if no additional expenses -->
                        <?php endif; ?>
                        <tr><td><strong>Total Spent:</strong> PHP <span id="totalSpentDisplay"><?php echo htmlspecialchars(number_format($event['totalSpentDisplay'], 2)); ?></span></td></tr>
                        <tr><td>&nbsp;</td></tr><!-- Adding space between events -->
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>  
</div>

<!-- Survey Modal -->
<div id="surveyModal" class="modal" style="display:none;">  
    <div class="modal-content">  
      <span class="close" onclick="closeSurveyModal()">&times;</span>  
      <h2>Survey</h2>  
      <form action="#" method='post'>  
          <label for='surveyQuestion'>Your feedback:</label><br/>  
          <input type='text' id='surveyQuestion' name='surveyQuestion' required /><br/>  
          <input type='submit' value='Submit' />  
      </form>  
    </div>  
</div>

<!-- Sponsor Modal -->
<div id="sponsorModal" class="modal" style="display:none;">  
    <div class="modal-content">  
      <span class="close" onclick="closeSponsorModal()">&times;</span>  
      <h2>Sponsor/Donate</h2>  
      <!-- Update this section with actual donation methods -->
      <!-- For example, you might want to link to payment pages or provide QR codes -->
      <!-- Ensure these details are accurate and secure -->
      Gcash/Maya Contact Number:<br/>
      Phone Number - 09691689364<br/>
      <!-- You can add more details here as needed -->
    </div>  
</div>

<!-- Closing tags for main content and body -->
</section>

</main>

</div>

<script src="js/modals.js"></script>
<script src="js/skreep.js"></script>
<script src="js/budget.js"></script>
<script src="js/survey.js"></script>

<?php $conn->close(); ?>  

</body>
</html>