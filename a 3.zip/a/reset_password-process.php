<?php
session_start();
include('db_connection.php'); // Include your database connection file

// Initialize modal messages
$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $email = $_POST['email']; // Get email from form
    $last_password = $_POST['last_password']; // Last remembered password
    $new_password = $_POST['new_password']; // New password

    // Fetch user data from database
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Verify if last remembered password matches
        if ($user && password_verify($last_password, $user['password'])) {
            // Update with new password
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE users SET password='$hashed_new_password' WHERE email='$email'";
            
            if (mysqli_query($conn, $update_sql)) {
                // Set success message for modal
                $success_message = "Password has been updated successfully!";
            } else {
                $error_message = "Error updating password: " . mysqli_error($conn);
            }
        } else {
            $error_message = "The last remembered password is incorrect.";
        }
    } else {
        $error_message = "User not found.";
    }
}

// Store messages in session variables for modal display
if ($error_message) {
    $_SESSION['error_message'] = $error_message;
} elseif ($success_message) {
    $_SESSION['success_message'] = $success_message;
}

// Redirect back to the forgot password page
header("Location: forgot_password.php");
exit();
?>