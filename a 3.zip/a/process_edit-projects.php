<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'db_connection.php';

date_default_timezone_set('Asia/Manila');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['project_name'];
    $date = $_POST['project_date'];
    $time = $_POST['project_time'];
    $type = $_POST['project_type'];
    $description = $_POST['project_description'];
    $location = $_POST['project_location'];
    $organizer = $_POST['project_organizer'];

    $imagePath = null;

    if (isset($_FILES['project_image'])) {
        if ($_FILES['project_image']['error'] === UPLOAD_ERR_OK) {
            $targetDir = 'uploads/';
            $fileName = basename($_FILES["project_image"]["name"]);
            $targetFilePath = $targetDir . $fileName;

            if (move_uploaded_file($_FILES["project_image"]["tmp_name"], $targetFilePath)) {
                $imagePath = $targetFilePath;
            } else {
                echo "Error moving uploaded file.";
                exit();
            }
        } else {
            switch ($_FILES['project_image']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                    echo "The uploaded file exceeds the upload_max_filesize directive in php.ini.";
                    break;
                case UPLOAD_ERR_FORM_SIZE:
                    echo "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.";
                    break;
                case UPLOAD_ERR_PARTIAL:
                    echo "The uploaded file was only partially uploaded.";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    echo "No file was uploaded.";
                    break;
                case UPLOAD_ERR_NO_TMP_DIR:
                    echo "Missing a temporary folder.";
                    break;
                case UPLOAD_ERR_CANT_WRITE:
                    echo "Failed to write file to disk.";
                    break;
                case UPLOAD_ERR_EXTENSION:
                    echo "A PHP extension stopped the file upload.";
                    break;
                default:
                    echo "Unknown upload error.";
                    break;
            }
            exit();
        }
    }

    $stmt = $conn->prepare("INSERT INTO projects (project_name, project_date, project_time, project_type, project_description, project_image, project_location, project_organizer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt) {
        $stmt->bind_param("ssssssss", 
            $name, 
            $date, 
            $time, 
            $type, 
            $description, 
            $imagePath, 
            $location, 
            $organizer
        );
        
        if ($stmt->execute()) {
            header("Location: projectsforadmin.php");
            exit();
        } else {
            die("Error adding project: " . htmlspecialchars($stmt->error));
        }
    } else {
        die("Error preparing statement: " . htmlspecialchars($conn->error));
    }
}
?>