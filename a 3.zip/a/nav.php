<nav>
    <div class="db">
        <ul>
            <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                <a href="admin_dashboard.php" class="dashboard-link">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <div class="dropdown-content" id="options">
                    <ul>
                        <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                        <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
            <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
        </ul>
    </div>

    <!-- User Info -->
    <div class="user-info">
        <span><?php echo htmlspecialchars($userName); ?></span> <!-- Safely display user name -->
    </div>

    <!-- Logout Link -->
    <a href="logout.php" class="logout">Log out</a> 

    <!-- Right Sidebar -->
    <aside class="right-sidebar">
        <h3>Quick Links</h3>
        <ul>
            <li><a href="#">User Management</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Notifications</a></li>
            <li><a href="#">Help Center</a></li>
        </ul>
    </aside>

    <!-- JavaScript for Dropdown -->
    <script type="text/javascript">
        function showOptions() {
            document.getElementById("options").style.display = "block";
        }

        function hideOptions() {
            document.getElementById("options").style.display = "none";
        }
    </script>

    <!-- CSS Styles -->
    <style>
        nav {
            background-color: #f8f9fa; /* Background color for the navigation */
            border-right: 1px solid #dee2e6; /* Right border for sidebar */
            height: 100%; /* Full height */
            width: 250px; /* Fixed width for sidebar */
            position: fixed; /* Fixed positioning */
            top: 0; /* Align to top */
            left: 0; /* Align to left */
            padding: 10px; /* Padding inside the nav */
        }

        .db {
            padding: 10px; /* Adjust padding as needed */
        }

        .db ul {
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
        }

        .db li {
            margin-bottom: 10px; /* Space between items */
        }

        .dashboard-link {
            text-decoration: none; /* Remove underline from links */
            color: #333; /* Text color */
        }

        .dropdown-content {
            display: none; /* Hidden by default */
            position: absolute; /* Positioning for dropdown */
            background-color: #ffffff; /* Background color for dropdown */
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2); /* Shadow effect for dropdown */
            z-index: 1; /* Ensure dropdown is above other content */
        }

        .dropdown:hover .dropdown-content {
            display: block; /* Show dropdown on hover */
        }

        .user-info {
            display: flex;
            align-items: center;
            margin-top: 20px;
        }

        .logout {
            margin-top: 20px; /* Adjust margin as needed */
        }

        .right-sidebar {
            margin-top: 20px; /* Adjust margin as needed */
        }
        
        aside.right-sidebar {
            background-color: #f1f1f1; /* Example background color for right sidebar */
            padding: 10px;
            border-left: 1px solid #dee2e6; /* Left border for right sidebar */
        }
        
        aside.right-sidebar h3 {
            margin-top: 0; /* Remove top margin from heading */
        }
        
        aside.right-sidebar ul {
            list-style-type: none; /* Remove bullet points from quick links */
            padding-left: 0;
        }
        
        aside.right-sidebar ul li a {
            text-decoration: none; /* Remove underline from links in sidebar */
            color: #007bff; /* Example link color */
        }
        
        aside.right-sidebar ul li a:hover {
            text-decoration: underline; /* Underline on hover for links in sidebar */
        }
    </style>
</nav>