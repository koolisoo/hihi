<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="css/style11.css">
</head>
<body>
    <section class="comm-login">
        <div class="wrapper">
            <div class="login-login">
                <form action="reset_password-process.php" method="post">
                    <h2>Reset Your Password</h2>
                    <br><br>
                    <input type="email" id="email" name="email" required placeholder="Enter your email">
                    <br><br>
                    <input type="password" id="last_password" name="last_password" required placeholder="Enter your last remembered password">
                    <br><br>
                    <input type="password" id="new_password" name="new_password" required placeholder="Enter your new password">
                    <br><br> 
                    <button type="submit">Reset Password</button>
                    <h4><a href="login.php" style="color: black;">Back to Login</a></h4>
                </form>
            </div>
        </div>
    </section>

    <?php if (isset($_SESSION['error_message'])) : ?>
    <div id="errorModal" class="modal" style="display:block;">
        <div class="modal-content">
            <p><?php echo $_SESSION['error_message']; ?></p>
            <button onclick="closeModal()">Okay</button> 
        </div>
    </div>
    <?php unset($_SESSION['error_message']); endif; ?>
    <?php if (isset($_SESSION['success_message'])) : ?>
    <div id="successModal" class="modal" style="display:block;">
        <div class="modal-content">
            <p><a href="login.php"style="text-decoration: none; color: #000000"><?php echo $_SESSION['success_message']; ?></p>
            <button onclick="closeModal()">Okay</button></a>
        </div>
    </div>
    <?php unset($_SESSION['success_message']); endif; ?>

    <script src="js/invalid-account.js"></script>

</body>
</html>