<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include('db_connection.php');

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$query = "SELECT * FROM reports";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$reports = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquidation Loom</title>
    <link rel="stylesheet" href="css/reports.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="logo">
                <a href="admin_dashboard.php"><img src="img/logo.png" alt="Liquidation Loom Logo"></a>
            </div>
            <nav>
    <div class="db">
        <ul>
            <li class="dropdown" onmouseenter="showOptions()" onmouseleave="hideOptions()">
                <a href="admin_dashboard.php" class="dashboard-link">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <div class="dropdown-content" id="options">
                    <ul>
                        <li><a href="eventsforadmin.php"><i class="fas fa-calendar-alt"></i> Events</a></li>
                        <li><a href="projectsforadmin.php"><i class="fas fa-project-diagram"></i> Projects</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="reports.php"><i class="fas fa-file-alt"></i> Reports</a></li>
            <li><a href="activitylog.php"><i class="fas fa-history"></i> Activity Log</a></li>
        </ul>
    </div>
</nav>
            <a href="logout.php" class="logout">Log out</a>
        </aside>

        <main class="main-content">
            <header class="header">
                <h1>Reports</h1>
                <div class="profile"></div>
            </header>

            <button class="addButton" id="addButton">Add</button>

            <div class="overlay" id="overlay"></div>
            <div class="popup-form" id="popupForm">
                <h2>Add Report</h2>
                <form action="report-process.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="category">Category:</label>
                        <input type="text" id="category" name="category" required placeholder="Enter report category">
                    </div>

                    <div class="form-group">
                        <label for="month">Month:</label>
                        <input type="text" id="month" name="month" required placeholder="Enter month">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="submit-button">Submit</button>
                        <button type="button" id="closeButton" class="cancel-button">Close</button>
                    </div>
                </form>
            </div>

            <div id="printableArea" style="display:none;">
                <h2>Report Details</h2>
                <p>Category: <span id="reportCategory"></span></p>
                <p>Month: <span id="reportMonth"></span></p>
            </div>

            <table>
    <thead>
        <tr>
            <th>Category</th>
            <th>Month</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($reports) > 0): ?>
            <?php foreach ($reports as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                    <td><?php echo htmlspecialchars($row['month']); ?></td>
                    <td class="action-buttons">
    <button class="downloadButton" data-category="<?php echo htmlspecialchars($row['category']); ?>" data-month="<?php echo htmlspecialchars($row['month']); ?>">Download</button>
    <button onclick="printReport('<?php echo htmlspecialchars($row['category']); ?>', '<?php echo htmlspecialchars($row['month']); ?>')">Print</button>
    <button id="deleteButton">Delete</button>
</td>



                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">No reports found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<button id="printAllButton">Print All Reports</button>
<div id="printableArea" style="display:none;"></div>

            <div class='button-container'>
                <button id='previousButton'>Previous</button>
                <button id='nextButton'>Next</button>
            </div>
    </main>
</div>

    <script src='js/skreep.js'></script> 
    <script src='js/print.js'></script> 
    <script src='js/download.js'></script> 
    <script src='js/add.js'></script> 
</body>
</html>
