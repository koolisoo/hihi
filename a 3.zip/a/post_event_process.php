<?php
include('db_connection.php');

$title = $_POST['title'];
$description = $_POST['description'];
$photo = $_FILES['photo']['name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($photo);

move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);

$sql = "INSERT INTO events (title, description, photo) VALUES ('$title', '$description', '$target_file')";
if (mysqli_query($conn, $sql)) {
    header("Location: eventsforadmin.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>