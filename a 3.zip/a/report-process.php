<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include('db_connection.php');

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "Form submitted!<br>";

    $category = $_POST['category'];
    $month = $_POST['month'];

    echo "Category: $category, Month: $month<br>";

    $stmt = $conn->prepare("INSERT INTO reports (category, month) VALUES (?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("ss", $category, $month);

    if ($stmt->execute()) {
        header("Location: reports.php");
        exit;
    } else {
        echo "Error: " . htmlspecialchars($stmt->error);
    }

    $stmt->close();
}

$conn->close();
?>